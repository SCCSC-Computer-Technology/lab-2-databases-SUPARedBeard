﻿namespace J_Pitts_Lab_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.populationDataSet = new J_Pitts_Lab_2.PopulationDataSet();
            this.populationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.populationTableAdapter = new J_Pitts_Lab_2.PopulationDataSetTableAdapters.PopulationTableAdapter();
            this.tableAdapterManager = new J_Pitts_Lab_2.PopulationDataSetTableAdapters.TableAdapterManager();
            this.populationBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.populationBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.populationDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.exitBtn = new System.Windows.Forms.Button();
            this.lowBtn = new System.Windows.Forms.Button();
            this.highBtn = new System.Windows.Forms.Button();
            this.totalPop = new System.Windows.Forms.Button();
            this.aveBtn = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.populationDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationBindingNavigator)).BeginInit();
            this.populationBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.populationDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // populationDataSet
            // 
            this.populationDataSet.DataSetName = "PopulationDataSet";
            this.populationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // populationBindingSource
            // 
            this.populationBindingSource.DataMember = "Population";
            this.populationBindingSource.DataSource = this.populationDataSet;
            // 
            // populationTableAdapter
            // 
            this.populationTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PopulationTableAdapter = this.populationTableAdapter;
            this.tableAdapterManager.UpdateOrder = J_Pitts_Lab_2.PopulationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // populationBindingNavigator
            // 
            this.populationBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.populationBindingNavigator.BindingSource = this.populationBindingSource;
            this.populationBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.populationBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.populationBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.populationBindingNavigatorSaveItem});
            this.populationBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.populationBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.populationBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.populationBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.populationBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.populationBindingNavigator.Name = "populationBindingNavigator";
            this.populationBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.populationBindingNavigator.Size = new System.Drawing.Size(960, 25);
            this.populationBindingNavigator.TabIndex = 0;
            this.populationBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // populationBindingNavigatorSaveItem
            // 
            this.populationBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.populationBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("populationBindingNavigatorSaveItem.Image")));
            this.populationBindingNavigatorSaveItem.Name = "populationBindingNavigatorSaveItem";
            this.populationBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.populationBindingNavigatorSaveItem.Text = "Save Data";
            this.populationBindingNavigatorSaveItem.Click += new System.EventHandler(this.populationBindingNavigatorSaveItem_Click);
            // 
            // populationDataGridView
            // 
            this.populationDataGridView.AllowUserToOrderColumns = true;
            this.populationDataGridView.AutoGenerateColumns = false;
            this.populationDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.populationDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.populationDataGridView.DataSource = this.populationBindingSource;
            this.populationDataGridView.Location = new System.Drawing.Point(250, 71);
            this.populationDataGridView.Name = "populationDataGridView";
            this.populationDataGridView.Size = new System.Drawing.Size(461, 221);
            this.populationDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CityID";
            this.dataGridViewTextBoxColumn1.HeaderText = "CityID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn2.HeaderText = "City";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn3.HeaderText = "State";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Population";
            this.dataGridViewTextBoxColumn4.HeaderText = "Population";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // exitBtn
            // 
            this.exitBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitBtn.Location = new System.Drawing.Point(409, 512);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(123, 51);
            this.exitBtn.TabIndex = 2;
            this.exitBtn.Text = "Exit";
            this.toolTip1.SetToolTip(this.exitBtn, "To exit form");
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // lowBtn
            // 
            this.lowBtn.Location = new System.Drawing.Point(754, 405);
            this.lowBtn.Name = "lowBtn";
            this.lowBtn.Size = new System.Drawing.Size(123, 51);
            this.lowBtn.TabIndex = 3;
            this.lowBtn.Text = "Lowest Population";
            this.toolTip1.SetToolTip(this.lowBtn, "To calculate lowest population");
            this.lowBtn.UseVisualStyleBackColor = true;
            this.lowBtn.Click += new System.EventHandler(this.lowBtn_Click);
            // 
            // highBtn
            // 
            this.highBtn.Location = new System.Drawing.Point(517, 405);
            this.highBtn.Name = "highBtn";
            this.highBtn.Size = new System.Drawing.Size(123, 51);
            this.highBtn.TabIndex = 4;
            this.highBtn.Text = "Highest Population";
            this.toolTip1.SetToolTip(this.highBtn, "To calculate highest population");
            this.highBtn.UseVisualStyleBackColor = true;
            this.highBtn.Click += new System.EventHandler(this.highBtn_Click);
            // 
            // totalPop
            // 
            this.totalPop.Location = new System.Drawing.Point(279, 405);
            this.totalPop.Name = "totalPop";
            this.totalPop.Size = new System.Drawing.Size(123, 51);
            this.totalPop.TabIndex = 5;
            this.totalPop.Text = "Total Population";
            this.toolTip1.SetToolTip(this.totalPop, "To calculate total population");
            this.totalPop.UseVisualStyleBackColor = true;
            this.totalPop.Click += new System.EventHandler(this.totalPop_Click);
            // 
            // aveBtn
            // 
            this.aveBtn.Location = new System.Drawing.Point(69, 405);
            this.aveBtn.Name = "aveBtn";
            this.aveBtn.Size = new System.Drawing.Size(123, 51);
            this.aveBtn.TabIndex = 6;
            this.aveBtn.Text = "Average Population";
            this.toolTip1.SetToolTip(this.aveBtn, "To calculate average population");
            this.aveBtn.UseVisualStyleBackColor = true;
            this.aveBtn.Click += new System.EventHandler(this.aveBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.totalPop;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.CancelButton = this.exitBtn;
            this.ClientSize = new System.Drawing.Size(960, 575);
            this.Controls.Add(this.aveBtn);
            this.Controls.Add(this.totalPop);
            this.Controls.Add(this.highBtn);
            this.Controls.Add(this.lowBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.populationDataGridView);
            this.Controls.Add(this.populationBindingNavigator);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Population";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.populationDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationBindingNavigator)).EndInit();
            this.populationBindingNavigator.ResumeLayout(false);
            this.populationBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.populationDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PopulationDataSet populationDataSet;
        private System.Windows.Forms.BindingSource populationBindingSource;
        private PopulationDataSetTableAdapters.PopulationTableAdapter populationTableAdapter;
        private PopulationDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator populationBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton populationBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView populationDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button lowBtn;
        private System.Windows.Forms.Button highBtn;
        private System.Windows.Forms.Button totalPop;
        private System.Windows.Forms.Button aveBtn;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

