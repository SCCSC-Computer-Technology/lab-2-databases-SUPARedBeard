﻿//Josh Pitts
//CPT 206
//Lab 2

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace J_Pitts_Lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //save items with acry catch for errors
        private void populationBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.populationBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.populationDataSet);
                MessageBox.Show("Changes saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving changes: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDataSet.Population' table. You can move, or remove it, as needed.
            this.populationTableAdapter.Fill(this.populationDataSet.Population);

        }

        //exit and save inputs on form
        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.populationTableAdapter.Update(this.populationDataSet);
            this.Close();
        }

        //button to calculate and display average population
        private void aveBtn_Click(object sender, EventArgs e)
        {
            double avePop = populationDataSet.Population.Average(row => row.Population);
            MessageBox.Show($"Average Population: {avePop:F2}", "Average Population", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //button to calculate total population and display
        private void totalPop_Click(object sender, EventArgs e)
        {
            int totalPop = populationDataSet.Population.Sum(row => row.Population);
            MessageBox.Show($"Total Population : {totalPop}", "Total Population", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //button to get the highest population and display
        private void highBtn_Click(object sender, EventArgs e)
        {
            var highPop = populationDataSet.Population.OrderByDescending(row => row.Population).FirstOrDefault();
            if (highPop != null)
            {
                MessageBox.Show($"The City with the highest population: \nCity: {highPop.City}\nPopulation: {highPop.Population}", "Highest Population", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //button to get the lowest population and display
        private void lowBtn_Click(object sender, EventArgs e)
        {
            var lowPop = populationDataSet.Population.OrderBy(row => row.Population).FirstOrDefault();
            if (lowPop != null)
            {
                MessageBox.Show($"The City with the lowest population: \nCity: {lowPop.City}\nPopulation: {lowPop.Population}", "Highest Population", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
